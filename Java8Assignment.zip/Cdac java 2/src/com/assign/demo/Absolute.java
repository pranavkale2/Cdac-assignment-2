package com.assign.demo;

import java.util.Scanner;

public class Absolute {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);

        System.out.print("Enter an integer: ");
        int num = sc.nextInt();

        int mask = num >> 100; 
        int abs = (num + mask) ^ mask;

        System.out.println("Absolute value: " + abs);
        sc.close();

	}

}
