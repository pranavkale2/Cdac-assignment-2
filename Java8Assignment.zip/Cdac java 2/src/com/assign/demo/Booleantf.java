package com.assign.demo;

import java.util.Scanner;

public class Booleantf {

	public static void main(String[] args) {
		 Scanner sc = new Scanner(System.in);

	        System.out.print("Enter first boolean (true/false): ");
	        boolean a = sc.nextBoolean();
	        System.out.print("Enter second boolean (true/false): ");
	        boolean b = sc.nextBoolean();
	        System.out.print("Enter third boolean (true/false): ");
	        boolean c = sc.nextBoolean();

	        boolean result = (a && b) || (b && c) || (a && c);

	        System.out.println("At least two are true: " + result);
	        sc.close();
	}

}
