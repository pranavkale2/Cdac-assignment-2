package com.assign.demo;

import java.util.Scanner;

public class Multiplyby8 {

	public static void main(String[] args) {
		 Scanner sc = new Scanner(System.in);

        System.out.print("Enter a number: ");
        int n = sc.nextInt();

        int result = n << 3;  

        System.out.println(n + " multiplied by 8 is: " + result);
        sc.close();
	}

}
